package in.nic.ashwini.eForms.models;

import lombok.Data;

@Data
public class NextHopBean {
	private String email;
	private String name;
	private String designation;
	private String mobile;
	private String role;
	private String status;
}
