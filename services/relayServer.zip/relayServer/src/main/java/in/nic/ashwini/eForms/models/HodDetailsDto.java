package in.nic.ashwini.eForms.models;

import lombok.Data;

@Data
public class HodDetailsDto {
	private String email;
	private String firstName;
	private String mobile;
	private String designation;
	private String telephoneNumber;
}
