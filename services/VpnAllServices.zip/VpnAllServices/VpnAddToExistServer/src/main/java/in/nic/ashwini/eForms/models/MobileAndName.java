package in.nic.ashwini.eForms.models;

import lombok.Data;

@Data
public class MobileAndName {
	private String mobile;
	private String name;
}
