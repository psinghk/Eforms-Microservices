package in.nic.ashwini.eForms.models;



public class PathDetailsDto {

	private Object vpnNumber;

	public PathDetailsDto() {
		super();
	}

	public Object getVpnNumber() {
		return vpnNumber;
	}

	public void setVpnNumber(Object vpnNumber) {
		this.vpnNumber = vpnNumber;
	}

	@Override
	public String toString() {
		return "PathDetailsDto [vpnNumber=" + vpnNumber + "]";
	}
	 

	
	
}
